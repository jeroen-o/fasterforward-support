Deze map bestaat uit "projecten" waarbij de juiste instellingen en waarden voor de conversie zijn toegepast.
Kies voor de juiste SQL Server versie waar u gebruik van maakt!