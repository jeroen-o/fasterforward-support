Twee varianten van de lege Adviesbox SQL database bijgesloten:
- Hypobox_SQL_Data.MDF plus Hypobox_SQL_Log.LDF
  Via 'Attach' in Management Studio toe te voegen.
- Hypobox_SQL.bak
  Via 'Restore' in Management Studio toe te voegen.

Slechts één van deze twee opties dient gebruikt te worden.
